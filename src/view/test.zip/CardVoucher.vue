<template>
    <div class="card-voucher">
        <div class="tip">提示:此处只可见优惠券，如需查看支付宝代金券可前往支付宝卡包。</div>
        
    </div>
</template>