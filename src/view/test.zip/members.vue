<template>
    <div class="members">
        <UnSignMembers/>
        <div class="actions flex">
            <div class="item flex flex-1">
                <div class="icon">icon</div>
                <div class="title">我的积分 {{ 0 }}</div>
            </div>
            <div class="item flex flex-1">
                <div class="icon">icon</div>
                <div class="title">成长任务</div>
            </div>
        </div>
    </div>
</template>
<script>
import UnSignMembers from './components/UnSignMembers.vue'
export default {
 components: {UnSignMembers}
}
</script>
<style lang="scss" scoped>
.flex {
    display: flex;
}
.flex-1 {
    flex: 1;
}
</style>